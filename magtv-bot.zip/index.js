import express from "express";
import sqlite3 from "sqlite3";
import bodyParser from "body-parser";

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Banco de dados SQLite
const db = new sqlite3.Database("./catalogo.db", (err) => {
  if (err) {
    console.error("Erro ao abrir o banco:", err.message);
  } else {
    console.log("Banco conectado com sucesso.");
  }
});

// Função para buscar no catálogo
function buscarCatalogo(titulo, callback) {
  const sql = "SELECT titulo FROM catalogo WHERE titulo LIKE ? LIMIT 20";
  db.all(sql, [`%${titulo}%`], (err, rows) => {
    if (err) {
      callback(err, null);
    } else {
      callback(null, rows);
    }
  });
}

// Webhook principal (Dialogflow)
app.post("/webhook", (req, res) => {
  const pergunta = req.body.queryResult.queryText;
  const intent = req.body.queryResult.intent.displayName;

  if (intent === "Novo Cliente") {
    res.json({
      fulfillmentText:
        "Temos apenas 1 plano de assinatura 👉 Mensal: R$ 30,00.
Inclui mais de 2.000 canais, 20 mil filmes, 14 mil séries e novelas, animes e desenhos.
Funciona em Smart TVs Samsung, LG, Roku e dispositivos Android (TV Box, Android TV, celulares). Não funciona em iOS.
Você vai usar em SMARTV, ANDROIDTV ou Celular? Qual a marca do dispositivo?
Você tem direito a um teste grátis de 3 horas. Aguarde um momento!",
    });
  } else if (intent === "Pagamento") {
    res.json({
      fulfillmentText:
        "👉 Chave PIX: 94 98444-5961
👉 Nome: Davi Eduardo Borges
👉 Valor: R$ 30,00
Por favor, envie o comprovante após o pagamento.",
    });
  } else if (intent === "Suporte") {
    res.json({
      fulfillmentText:
        "Por favor, me informe seu Nome e Sobrenome.
Depois aguarde um momento, vou encaminhar seu atendimento para o suporte.",
    });
  } else if (intent === "Consultar Conteúdo") {
    const termo = pergunta.replace("tem", "").trim();
    buscarCatalogo(termo, (err, rows) => {
      if (err) {
        res.json({ fulfillmentText: "Erro ao consultar o catálogo." });
      } else if (rows.length > 0) {
        const titulos = rows.map((r) => r.titulo).join(", ");
        res.json({
          fulfillmentText: `Encontrei os seguintes conteúdos no catálogo: ${titulos}`,
        });
      } else {
        res.json({
          fulfillmentText:
            "Infelizmente não encontrei este título no catálogo, mas temos milhares de outras opções. Deseja que eu sugira algo parecido?",
        });
      }
    });
  } else {
    res.json({
      fulfillmentText:
        "Oi! Eu sou a Dani da MAGTV IPTV. Posso te ajudar com:
1️⃣ Novo Cliente
2️⃣ Pagamento
3️⃣ Suporte
4️⃣ Consultar Conteúdo",
    });
  }
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
