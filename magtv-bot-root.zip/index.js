import express from "express";
import sqlite3 from "sqlite3";
import bodyParser from "body-parser";

const app = express();
const db = new sqlite3.Database("./catalogo.db");

app.use(bodyParser.json());

// Rota principal (Dialogflow Webhook)
app.post("/webhook", (req, res) => {
  const pergunta = req.body.queryResult.queryText.toLowerCase();
  let resposta = "";

  if (pergunta.includes("novo cliente") || pergunta === "1") {
    resposta = "Temos apenas 1 plano: Mensal por R$30,00. Inclui mais de 2.000 canais e milhares de filmes e séries. Em qual dispositivo você pretende usar (SMARTV, ANDROIDTV ou Celular)?";
  } else if (pergunta.includes("pagamento") || pergunta === "2") {
    resposta = "👉 Chave PIX: 94 98444-5961\n👉 Nome: Davi Eduardo Borges\n👉 Valor: R$ 30,00\nEnvie o comprovante após o pagamento.";
  } else if (pergunta.includes("suporte") || pergunta === "3") {
    resposta = "Por favor, me informe seu Nome e Sobrenome. Vou encaminhar seu atendimento ao suporte.";
  } else if (pergunta.includes("consultar") || pergunta === "4") {
    resposta = "Por favor, digite o nome do filme, série ou anime que deseja buscar.";
  } else {
    // Consulta no banco de dados
    db.all("SELECT titulo FROM catalogo WHERE titulo LIKE ?", [`%${pergunta}%`], (err, rows) => {
      if (err) {
        return res.json({ fulfillmentText: "Erro ao consultar catálogo." });
      }
      if (rows.length > 0) {
        const lista = rows.map(r => r.titulo).slice(0, 5).join(", ");
        return res.json({ fulfillmentText: `Encontrei: ${lista} ...` });
      } else {
        return res.json({ fulfillmentText: "Infelizmente não encontrei este título no catálogo, mas temos milhares de outras opções. Deseja que eu sugira algo parecido?" });
      }
    });
    return;
  }

  res.json({ fulfillmentText: resposta });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
